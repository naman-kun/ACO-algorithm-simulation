## Packages
d3-force | Physics-based layout for initial network graph generation
d3-scale | Color scales for heatmaps/pheromones

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["var(--font-display)"],
  mono: ["var(--font-mono)"],
  sans: ["var(--font-sans)"],
}
